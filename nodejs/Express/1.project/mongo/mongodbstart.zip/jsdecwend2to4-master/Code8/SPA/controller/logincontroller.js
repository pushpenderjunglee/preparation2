app.controller("loginCtrl",function($scope){
    $scope.pagetitle="Login Page";
});