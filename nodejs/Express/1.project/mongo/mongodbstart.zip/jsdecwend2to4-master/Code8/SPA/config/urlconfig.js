app.constant("LOGIN","/login");
app.constant("REGISTER","/register");
app.constant("ABOUT","/aboutus");