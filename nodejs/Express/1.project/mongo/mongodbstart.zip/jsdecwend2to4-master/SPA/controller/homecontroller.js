app.controller("homeCtrl",function($scope){
    $scope.msg = "Welcome to the Home Page";
});