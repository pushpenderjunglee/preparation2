document.querySelector("aa");
null
document.querySelector("#aa");
<div id=​"aa">​</div>​
var x = document.querySelector("#aa");
undefined
var img = document.createElement("img");
undefined
img;
<img>​
img.src ="https://images-eu.ssl-images-amazon.com/images/I/71Bveild+AL.AC_AA200.jpg";
"https://images-eu.ssl-images-amazon.com/images/I/71Bveild+AL.AC_AA200.jpg"
img;
<img src=​"https:​/​/​images-eu.ssl-images-amazon.com/​images/​I/​71Bveild+AL.AC_AA200.jpg">​
x.appendChild(img);
<img src=​"https:​/​/​images-eu.ssl-images-amazon.com/​images/​I/​71Bveild+AL.AC_AA200.jpg">​
