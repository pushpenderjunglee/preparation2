class User{
  constructor(userid, pwd){
    this.userid = userid;
    this.pwd = pwd;
  }
}
module.exports = User;
