const authObject = {
  "userid":"iloveyousachin10@gmail.com",
  "password":"sachin@49475066"
}
module.exports = authObject;
