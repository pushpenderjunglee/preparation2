const obj = require("./first");
// console.log(addition);
// console.log("Sum is "+addition(1000,20000));
// console.log(addition.subtract(10,20));
console.log(obj.add(10,20));
console.log(obj.subtract(10,20));
