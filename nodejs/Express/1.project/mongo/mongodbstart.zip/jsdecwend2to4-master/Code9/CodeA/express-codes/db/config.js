const dbConfig = {
  "url":"mongodb://localhost:27017/onlineshop?maxPoolSize=10"
}
module.exports = dbConfig;
