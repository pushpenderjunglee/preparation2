const math = require("./index");
console.log(math.add(100,200));
console.log(math.multiply(100,200));
console.log(math.power(100,10));
