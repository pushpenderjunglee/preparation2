function power(x,y){
  return x **y;
}
module.exports = power;
