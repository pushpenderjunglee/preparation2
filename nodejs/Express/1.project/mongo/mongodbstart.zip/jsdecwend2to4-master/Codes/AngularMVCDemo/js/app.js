const app = angular.module("myapp", []);
console.log("App Loaded..");