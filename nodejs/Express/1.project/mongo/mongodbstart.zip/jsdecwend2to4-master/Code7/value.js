//app.value("LOCALURL", "http://localhost:4000/items");
app.constant("LOCALURL","http://localhost:4000/items");